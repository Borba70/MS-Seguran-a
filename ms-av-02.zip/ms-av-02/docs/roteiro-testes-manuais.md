# Roteiro de testes manuais (PostgreSQL real)

Pré-requisito: aplicação rodando (`mvn spring-boot:run`), usuários `admin` e `manutencao` criados via `.env`.
Use `curl` no **cmd.exe** (ou Postman/Swagger). Substitua `ADMIN_PASS` e `MANUT_PASS` pelas senhas do seu `.env`.
Anote o resultado de cada passo na coluna "Obtido" — não preencha sem executar.

| # | Passo | Comando | Esperado | Obtido |
|---|---|---|---|---|
| 1 | Cadastro autorizado | `curl -i -u manutencao:MANUT_PASS -X POST http://localhost:8080/ -H "Content-Type: application/json" -d "{\"username\":\"aluno\",\"senha\":\"SenhaForte#123\"}"` | 201 | |
| 2 | Cadastro duplicado | repetir o passo 1 | 409 | |
| 3 | Cadastro sem a role | `curl -i -u admin:ADMIN_PASS -X POST http://localhost:8080/ -H "Content-Type: application/json" -d "{\"username\":\"x1234\",\"senha\":\"SenhaForte#123\"}"` | 403 | |
| 4 | Cadastro sem autenticar | mesmo sem `-u` | 401 | |
| 5 | Listagem autorizada | `curl -i -u manutencao:MANUT_PASS http://localhost:8080/` | 200, sem senha/hash no JSON | |
| 6 | Listagem sem permissão | `curl -i -u admin:ADMIN_PASS http://localhost:8080/` | 403 | |
| 7 | Login válido | `curl -i -X POST http://localhost:8080/login -H "Content-Type: application/json" -d "{\"username\":\"aluno\",\"senha\":\"SenhaForte#123\"}"` | 200 | |
| 8 | Login inválido (1ª falha) | mesma chamada com senha errada | 401 | |
| 9 | Login inválido (2ª falha seguida) | idem | 401 + conta bloqueada | |
| 10 | Login de bloqueado (senha correta) | passo 7 | 401 (mensagem de conta bloqueada) | |
| 11 | Conferir no banco | `psql -U postgres -d msav02 -c "SELECT username, failed_attempts, locked, locked_at FROM login_attempts;"` | `locked = t` | |
| 12 | Métrica do gauge | `curl http://localhost:8080/actuator/prometheus` e procurar `usuarios_bloqueados` | 1.0 | |
| 13 | Desbloqueio por admin | `curl -i -u admin:ADMIN_PASS -X PUT http://localhost:8080/unlock/aluno` | 200 | |
| 14 | Desbloqueio de inexistente | `.../unlock/fantasma` | 404 | |
| 15 | Desbloqueio sem a role | `curl -i -u manutencao:MANUT_PASS -X PUT http://localhost:8080/unlock/aluno` | 403 | |
| 16 | Login após desbloqueio | passo 7 | 200 | |
| 17 | Troca de senha correta | `curl -i -X PUT http://localhost:8080/trocarsenha/aluno -H "Content-Type: application/json" -d "{\"atual\":\"SenhaForte#123\",\"nova\":\"OutraSenha#456\"}"` | 200 | |
| 18 | Troca com senha atual errada | atual incorreta | 401 | |
| 19 | Troca de usuário inexistente | `.../trocarsenha/fantasma` | 404 | |
| 20 | Hash no banco | `psql -U postgres -d msav02 -c "SELECT username, left(senha,4) FROM usuarios;"` | prefixo `$2a$` ou `$2b$` | |
| 21 | Counters | `curl http://localhost:8080/actuator/prometheus` e procurar `login_validos_total` / `login_invalidos_total` | valores coerentes com os passos | |
| 22 | Swagger | abrir http://localhost:8080/swagger-ui.html | página carrega com os 5 endpoints | |
| 23 | Rota inexistente | `curl -i http://localhost:8080/qualquer` | 401 (anônimo) | |
