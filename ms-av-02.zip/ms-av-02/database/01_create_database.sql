-- Execute UMA vez, conectado ao banco padrao "postgres":
--   psql -U postgres -f database\01_create_database.sql
-- (CREATE DATABASE nao suporta IF NOT EXISTS; se o banco ja existir, ignore o erro.)
CREATE DATABASE msav02 ENCODING 'UTF8';
