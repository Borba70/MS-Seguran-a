-- APENAS DESENVOLVIMENTO: apaga todos os dados e tabelas do projeto.
-- psql -U postgres -d msav02 -f database\03_reset_dev.sql
DROP TABLE IF EXISTS authorities;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS usuarios;
