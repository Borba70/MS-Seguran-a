package br.com.msav02.controller;

import br.com.msav02.dto.ErrorResponse;
import br.com.msav02.dto.MensagemResponse;
import br.com.msav02.dto.TrocaSenhaRequest;
import br.com.msav02.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Tag(name = "Senha")
public class SenhaController {

    private final UserService userService;

    public SenhaController(UserService userService) {
        this.userService = userService;
    }

    @PutMapping(value = "/trocarsenha/{userid}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Troca a senha do usuário",
            description = "PUT /trocarsenha/{userid} — Público (exigência acadêmica). A identidade do titular é comprovada pela senha ATUAL. "
                    + "Senha atual incorreta conta como falha (mesmo limite de bloqueio do login). Veja os riscos no README.")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(
            examples = @ExampleObject(name = "Exemplo", value = "{\"atual\": \"SenhaAtual#123\", \"nova\": \"NovaSenha#456\"}")))
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Senha alterada",
                    content = @Content(schema = @Schema(implementation = MensagemResponse.class),
                            examples = @ExampleObject(value = "{\"mensagem\": \"Senha alterada com sucesso.\"}"))),
            @ApiResponse(responseCode = "400", description = "Dados inválidos (ex.: nova senha curta ou igual à atual)",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Senha atual incorreta",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                            examples = @ExampleObject(value = "{\"status\": 401, \"erro\": \"Unauthorized\", \"mensagem\": \"Senha atual incorreta.\"}"))),
            @ApiResponse(responseCode = "403", description = "Conta bloqueada",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Usuário inexistente",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                            examples = @ExampleObject(value = "{\"status\": 404, \"erro\": \"Not Found\", \"mensagem\": \"Usuário não encontrado.\"}")))
    })
    public ResponseEntity<MensagemResponse> trocarSenha(
            @Parameter(description = "Username do usuário", example = "aluno") @PathVariable("userid") String userid,
            @Valid @RequestBody TrocaSenhaRequest request) {
        return ResponseEntity.ok(userService.trocarSenha(userid, request));
    }
}
