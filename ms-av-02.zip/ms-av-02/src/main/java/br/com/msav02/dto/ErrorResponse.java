package br.com.msav02.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.util.List;

@Schema(description = "Formato padrão de erro")
public record ErrorResponse(
        Instant timestamp,
        int status,
        String erro,
        String mensagem,
        String caminho,
        List<String> detalhes) {

    public static ErrorResponse of(HttpStatus status, String mensagem, String caminho, List<String> detalhes) {
        return new ErrorResponse(Instant.now(), status.value(), status.getReasonPhrase(), mensagem, caminho, detalhes);
    }
}
