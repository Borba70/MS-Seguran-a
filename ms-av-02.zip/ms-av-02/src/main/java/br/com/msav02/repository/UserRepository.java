package br.com.msav02.repository;

import br.com.msav02.dto.UsuarioResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbc;

    public UserRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean exists(String username) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM usuarios WHERE username = ?", Integer.class, username);
        return n != null && n > 0;
    }

    public void updatePassword(String username, String hash) {
        jdbc.update("UPDATE usuarios SET senha = ? WHERE username = ?", hash, username);
    }

    public void setEnabled(String username, boolean enabled) {
        jdbc.update("UPDATE usuarios SET enabled = ? WHERE username = ?", enabled, username);
    }

    public List<String> findRoles(String username) {
        return jdbc.queryForList("SELECT authority FROM authorities WHERE username = ? ORDER BY authority",
                String.class, username);
    }

    /** Lista usuarios sem senha/hash: apenas username, estado e roles. */
    public List<UsuarioResponse> findAll() {
        Map<String, List<String>> roles = new HashMap<>();
        jdbc.query("SELECT username, authority FROM authorities ORDER BY authority",
                (RowCallbackHandler) rs -> roles
                        .computeIfAbsent(rs.getString("username"), k -> new ArrayList<>())
                        .add(rs.getString("authority")));

        return jdbc.query("""
                SELECT u.username, u.enabled, COALESCE(l.locked, FALSE) AS locked
                  FROM usuarios u
                  LEFT JOIN login_attempts l ON l.username = u.username
                 ORDER BY u.username
                """,
                (rs, i) -> new UsuarioResponse(
                        rs.getString("username"),
                        rs.getBoolean("enabled"),
                        rs.getBoolean("locked"),
                        roles.getOrDefault(rs.getString("username"), List.of())));
    }
}
