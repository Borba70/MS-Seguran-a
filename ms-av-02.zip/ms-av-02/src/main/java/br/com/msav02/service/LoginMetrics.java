package br.com.msav02.service;

import br.com.msav02.repository.LoginAttemptRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Metricas de login. Sem labels (nenhum dado pessoal e exposto).
 *
 * Counter "login_validos"   -> exposto pelo Prometheus como login_validos_total
 * Counter "login_invalidos" -> exposto como login_invalidos_total
 * Gauge   "usuarios_bloqueados_total" -> valor ATUAL lido do banco a cada coleta (sobe e desce).
 */
@Component
public class LoginMetrics {

    private static final Logger log = LoggerFactory.getLogger(LoginMetrics.class);

    private final Counter validos;
    private final Counter invalidos;

    public LoginMetrics(MeterRegistry registry, LoginAttemptRepository attempts) {
        this.validos = Counter.builder("login_validos")
                .description("Total acumulado de logins validos").register(registry);
        this.invalidos = Counter.builder("login_invalidos")
                .description("Total acumulado de logins invalidos").register(registry);
        Gauge.builder("usuarios_bloqueados_total", attempts, LoginMetrics::safeCount)
                .description("Quantidade atual de usuarios bloqueados")
                .strongReference(true)
                .register(registry);
    }

    public void registrarValido() {
        validos.increment();
    }

    public void registrarInvalido() {
        invalidos.increment();
    }

    private static double safeCount(LoginAttemptRepository repo) {
        try {
            return repo.countLocked();
        } catch (Exception e) {
            log.warn("Nao foi possivel consultar usuarios bloqueados para a metrica: {}", e.getClass().getSimpleName());
            return Double.NaN;
        }
    }
}
