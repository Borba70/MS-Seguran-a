package br.com.msav02.service;

import br.com.msav02.dto.CadastroUsuarioRequest;
import br.com.msav02.dto.MensagemResponse;
import br.com.msav02.dto.TrocaSenhaRequest;
import br.com.msav02.dto.UsuarioResponse;
import br.com.msav02.exception.ApiException;
import br.com.msav02.exception.InvalidCredentialsException;
import br.com.msav02.exception.UserAlreadyExistsException;
import br.com.msav02.exception.UserNotFoundException;
import br.com.msav02.repository.LoginAttemptRepository;
import br.com.msav02.repository.UserRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    private final JdbcUserDetailsManager userDetailsManager;
    private final PasswordEncoder encoder;
    private final UserRepository users;
    private final LoginAttemptRepository attemptsRepo;
    private final LoginAttemptService attempts;

    public UserService(JdbcUserDetailsManager userDetailsManager, PasswordEncoder encoder,
                       UserRepository users, LoginAttemptRepository attemptsRepo, LoginAttemptService attempts) {
        this.userDetailsManager = userDetailsManager;
        this.encoder = encoder;
        this.users = users;
        this.attemptsRepo = attemptsRepo;
        this.attempts = attempts;
    }

    /** Cria usuario com as roles informadas (sem prefixo ROLE_) e senha em BCrypt. */
    @Transactional
    public void criar(String username, String rawPassword, String... roles) {
        UserDetails details = User.withUsername(username)
                .password(encoder.encode(rawPassword))
                .roles(roles)
                .build();
        userDetailsManager.createUser(details);
        attemptsRepo.ensureRow(username);
    }

    /** POST / : cadastro por usuario de manutencao. O novo usuario recebe apenas ROLE_USER. */
    @Transactional
    public UsuarioResponse cadastrar(CadastroUsuarioRequest req) {
        if (users.exists(req.username())) {
            throw new UserAlreadyExistsException();
        }
        try {
            criar(req.username(), req.senha(), Roles.USER);
        } catch (DuplicateKeyException e) {
            throw new UserAlreadyExistsException();
        }
        return new UsuarioResponse(req.username(), true, false, users.findRoles(req.username()));
    }

    @Transactional(readOnly = true)
    public List<UsuarioResponse> listar() {
        return users.findAll();
    }

    /**
     * PUT /trocarsenha/{userid} (endpoint publico por exigencia academica).
     * A identidade do titular e comprovada pela senha ATUAL. Senha atual errada conta como falha
     * de tentativa (mesmo limite do login), senao o endpoint viraria um oraculo de forca bruta.
     * Metodo nao-transacional de proposito: o registro de falha precisa persistir mesmo com a excecao.
     */
    public MensagemResponse trocarSenha(String username, TrocaSenhaRequest req) {
        UserDetails user = carregar(username);
        if (user == null) {
            throw new UserNotFoundException();
        }
        if (attempts.estaBloqueado(username) || !user.isEnabled()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Conta bloqueada. Procure um administrador.");
        }
        if (!encoder.matches(req.atual(), user.getPassword())) {
            attempts.registrarFalha(username);
            throw new InvalidCredentialsException("Senha atual incorreta.");
        }
        if (req.atual().equals(req.nova())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "A nova senha deve ser diferente da atual.");
        }
        users.updatePassword(username, encoder.encode(req.nova()));
        attempts.registrarSucesso(username);
        return new MensagemResponse("Senha alterada com sucesso.");
    }

    private UserDetails carregar(String username) {
        try {
            return userDetailsManager.loadUserByUsername(username);
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }
}
