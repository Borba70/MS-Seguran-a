package br.com.msav02.service;

import br.com.msav02.dto.LoginRequest;
import br.com.msav02.dto.LoginResponse;
import br.com.msav02.exception.InvalidCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    static final String MSG_GENERICA = "Usuário ou senha inválidos.";
    static final String MSG_BLOQUEADA = "Conta bloqueada. Procure um administrador para desbloqueá-la.";

    private final UserDetailsService userDetailsService;
    private final PasswordEncoder encoder;
    private final LoginAttemptService attempts;
    private final LoginMetrics metrics;
    /** Hash descartavel: gasta o mesmo tempo de BCrypt quando o usuario nao existe (reduz enumeracao por tempo). */
    private final String dummyHash;

    public AuthService(UserDetailsService userDetailsService, PasswordEncoder encoder,
                       LoginAttemptService attempts, LoginMetrics metrics) {
        this.userDetailsService = userDetailsService;
        this.encoder = encoder;
        this.attempts = attempts;
        this.metrics = metrics;
        this.dummyHash = encoder.encode("hash-descartavel-nao-e-senha-real");
    }

    public LoginResponse login(LoginRequest req) {
        String username = req.username();
        UserDetails user = carregar(username);

        if (user == null) {
            encoder.matches(req.senha(), dummyHash);
            metrics.registrarInvalido();
            throw new InvalidCredentialsException(MSG_GENERICA);
        }

        boolean senhaCorreta = encoder.matches(req.senha(), user.getPassword());
        boolean bloqueado = attempts.estaBloqueado(username) || !user.isEnabled();

        if (bloqueado) {
            metrics.registrarInvalido();
            // So informa "bloqueada" a quem comprovou conhecer a senha; os demais veem a mensagem generica.
            throw new InvalidCredentialsException(senhaCorreta ? MSG_BLOQUEADA : MSG_GENERICA);
        }

        if (!senhaCorreta) {
            attempts.registrarFalha(username);
            metrics.registrarInvalido();
            throw new InvalidCredentialsException(MSG_GENERICA);
        }

        attempts.registrarSucesso(username);
        metrics.registrarValido();
        return new LoginResponse("Login realizado com sucesso.", username);
    }

    private UserDetails carregar(String username) {
        try {
            return userDetailsService.loadUserByUsername(username);
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }
}
