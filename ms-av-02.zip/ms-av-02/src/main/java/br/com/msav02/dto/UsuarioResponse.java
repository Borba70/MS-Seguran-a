package br.com.msav02.dto;

import java.util.List;

/** Visao publica de um usuario: NUNCA inclui senha nem hash. */
public record UsuarioResponse(String username, boolean enabled, boolean locked, List<String> roles) {
}
