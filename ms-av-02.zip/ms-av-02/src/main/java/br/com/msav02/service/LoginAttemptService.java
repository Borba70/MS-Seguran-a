package br.com.msav02.service;

import br.com.msav02.exception.UserNotFoundException;
import br.com.msav02.repository.LoginAttemptRepository;
import br.com.msav02.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Controla tentativas, bloqueio e desbloqueio. Cada metodo e uma transacao propria:
 * assim o registro de falha NAO e desfeito quando o chamador lanca excecao (HTTP 401).
 */
@Service
public class LoginAttemptService {

    private final LoginAttemptRepository attempts;
    private final UserRepository users;
    private final int maxFailedAttempts;

    public LoginAttemptService(LoginAttemptRepository attempts, UserRepository users,
                               @Value("${app.security.max-failed-attempts:2}") int maxFailedAttempts) {
        this.attempts = attempts;
        this.users = users;
        this.maxFailedAttempts = maxFailedAttempts;
    }

    @Transactional(readOnly = true)
    public boolean estaBloqueado(String username) {
        return attempts.isLocked(username);
    }

    /** Registra falha; ao atingir o limite trava a conta e desabilita o usuario (enabled=false). */
    @Transactional
    public void registrarFalha(String username) {
        attempts.ensureRow(username);
        attempts.incrementFailure(username, maxFailedAttempts);
        if (attempts.isLocked(username)) {
            users.setEnabled(username, false);
        }
    }

    @Transactional
    public void registrarSucesso(String username) {
        attempts.resetFailures(username);
    }

    @Transactional
    public void desbloquear(String username) {
        if (!users.exists(username)) {
            throw new UserNotFoundException();
        }
        attempts.ensureRow(username);
        attempts.unlock(username);
        users.setEnabled(username, true);
    }
}
