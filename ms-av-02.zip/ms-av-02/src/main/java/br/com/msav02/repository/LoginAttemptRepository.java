package br.com.msav02.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class LoginAttemptRepository {

    private final JdbcTemplate jdbc;

    public LoginAttemptRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void ensureRow(String username) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM login_attempts WHERE username = ?", Integer.class, username);
        if (n == null || n == 0) {
            jdbc.update("INSERT INTO login_attempts (username) VALUES (?)", username);
        }
    }

    public boolean isLocked(String username) {
        List<Boolean> r = jdbc.queryForList("SELECT locked FROM login_attempts WHERE username = ?", Boolean.class, username);
        return !r.isEmpty() && Boolean.TRUE.equals(r.get(0));
    }

    /**
     * Incremento ATOMICO (uma unica instrucao UPDATE): evita corrida entre requisicoes
     * concorrentes. Trava a conta quando atinge o limite.
     */
    public void incrementFailure(String username, int maxAttempts) {
        jdbc.update("""
                UPDATE login_attempts
                   SET failed_attempts = failed_attempts + 1,
                       last_failed_at  = LOCALTIMESTAMP,
                       updated_at      = LOCALTIMESTAMP,
                       locked          = (failed_attempts + 1 >= ?),
                       locked_at       = CASE WHEN failed_attempts + 1 >= ? THEN LOCALTIMESTAMP ELSE locked_at END
                 WHERE username = ? AND locked = FALSE
                """, maxAttempts, maxAttempts, username);
    }

    /** Zera falhas consecutivas apos login valido (nao mexe em contas ja bloqueadas). */
    public void resetFailures(String username) {
        jdbc.update("""
                UPDATE login_attempts
                   SET failed_attempts = 0, updated_at = LOCALTIMESTAMP
                 WHERE username = ? AND locked = FALSE AND failed_attempts <> 0
                """, username);
    }

    public void unlock(String username) {
        jdbc.update("""
                UPDATE login_attempts
                   SET failed_attempts = 0, locked = FALSE, locked_at = NULL, updated_at = LOCALTIMESTAMP
                 WHERE username = ?
                """, username);
    }

    public long countLocked() {
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM login_attempts WHERE locked = TRUE", Long.class);
        return n == null ? 0L : n;
    }
}
