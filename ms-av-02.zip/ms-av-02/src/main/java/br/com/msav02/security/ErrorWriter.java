package br.com.msav02.security;

import br.com.msav02.dto.ErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

final class ErrorWriter {

    private ErrorWriter() {
    }

    static void write(ObjectMapper mapper, HttpServletResponse res, HttpStatus status, String msg, String path) throws IOException {
        res.setStatus(status.value());
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setCharacterEncoding(StandardCharsets.UTF_8.name());
        mapper.writeValue(res.getOutputStream(), ErrorResponse.of(status, msg, path, null));
    }
}
