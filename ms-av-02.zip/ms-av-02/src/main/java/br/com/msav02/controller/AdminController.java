package br.com.msav02.controller;

import br.com.msav02.dto.ErrorResponse;
import br.com.msav02.dto.MensagemResponse;
import br.com.msav02.service.LoginAttemptService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Tag(name = "Administração")
public class AdminController {

    private final LoginAttemptService attempts;

    public AdminController(LoginAttemptService attempts) {
        this.attempts = attempts;
    }

    @PutMapping(value = "/unlock/{userid}", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Desbloqueia a conta de um usuário",
            description = "PUT /unlock/{userid} — Requer ROLE_ADMIN (HTTP Basic). Zera o contador de falhas, remove o bloqueio e "
                    + "reabilita o usuário (enabled = true).",
            security = @SecurityRequirement(name = "basicAuth"))
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Conta desbloqueada",
                    content = @Content(schema = @Schema(implementation = MensagemResponse.class),
                            examples = @ExampleObject(value = "{\"mensagem\": \"Usuário desbloqueado com sucesso.\"}"))),
            @ApiResponse(responseCode = "401", description = "Não autenticado",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "403", description = "Sem ROLE_ADMIN",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Usuário inexistente",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                            examples = @ExampleObject(value = "{\"status\": 404, \"erro\": \"Not Found\", \"mensagem\": \"Usuário não encontrado.\"}")))
    })
    public ResponseEntity<MensagemResponse> desbloquear(
            @Parameter(description = "Username do usuário", example = "aluno") @PathVariable("userid") String userid) {
        attempts.desbloquear(userid);
        return ResponseEntity.ok(new MensagemResponse("Usuário desbloqueado com sucesso."));
    }
}
