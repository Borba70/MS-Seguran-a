package br.com.msav02.config;

import br.com.msav02.repository.UserRepository;
import br.com.msav02.service.Roles;
import br.com.msav02.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
 * Cria o administrador e o usuario de manutencao iniciais a partir de variaveis de ambiente / .env.
 * Nenhuma credencial existe no codigo-fonte. Usuario so e criado se username e senha (>= 8) forem informados
 * e se ele ainda nao existir. Nunca registra senhas em log.
 */
@Component
public class BootstrapUsersRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(BootstrapUsersRunner.class);

    private final UserService userService;
    private final UserRepository users;
    private final String adminUser;
    private final String adminPass;
    private final String manutUser;
    private final String manutPass;

    public BootstrapUsersRunner(UserService userService, UserRepository users,
                                @Value("${app.bootstrap.admin.username:}") String adminUser,
                                @Value("${app.bootstrap.admin.password:}") String adminPass,
                                @Value("${app.bootstrap.manutencao.username:}") String manutUser,
                                @Value("${app.bootstrap.manutencao.password:}") String manutPass) {
        this.userService = userService;
        this.users = users;
        this.adminUser = adminUser;
        this.adminPass = adminPass;
        this.manutUser = manutUser;
        this.manutPass = manutPass;
    }

    @Override
    public void run(ApplicationArguments args) {
        criarSeAusente(adminUser, adminPass, Roles.ADMIN);
        criarSeAusente(manutUser, manutPass, Roles.MANUTENCAO);
    }

    private void criarSeAusente(String username, String password, String role) {
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            log.warn("Usuario inicial com role {} NAO configurado (defina as variaveis BOOTSTRAP_* no .env).", role);
            return;
        }
        if (password.length() < 8 || password.length() > 72) {
            log.warn("Senha do usuario inicial com role {} ignorada: deve ter entre 8 e 72 caracteres.", role);
            return;
        }
        if (users.exists(username)) {
            log.info("Usuario inicial com role {} ja existe; nada a fazer.", role);
            return;
        }
        userService.criar(username, password, role);
        log.info("Usuario inicial com role {} criado.", role);
    }
}
