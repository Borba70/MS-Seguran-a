package br.com.msav02.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record TrocaSenhaRequest(
        @Schema(example = "SenhaAtual#123") @NotBlank(message = "senha atual é obrigatória") @Size(max = 128, message = "senha atual muito longa") String atual,
        @Schema(example = "NovaSenha#456") @NotBlank(message = "nova senha é obrigatória") @Size(min = 8, max = 72, message = "nova senha deve ter entre 8 e 72 caracteres") String nova) {
}
