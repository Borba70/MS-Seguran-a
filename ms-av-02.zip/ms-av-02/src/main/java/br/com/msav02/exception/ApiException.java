package br.com.msav02.exception;

import org.springframework.http.HttpStatus;

/** Excecao de negocio que carrega o status HTTP a ser devolvido. */
public class ApiException extends RuntimeException {

    private final HttpStatus status;

    public ApiException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
