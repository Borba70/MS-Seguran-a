package br.com.msav02.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CadastroUsuarioRequest(
        @Schema(example = "novoUsuario")
        @NotBlank(message = "username é obrigatório")
        @Pattern(regexp = "^[A-Za-z0-9._-]{3,100}$", message = "username deve ter 3 a 100 caracteres (letras, números, ponto, hífen ou sublinhado)")
        String username,
        @Schema(example = "senhaSegura#123")
        @NotBlank(message = "senha é obrigatória")
        @Size(min = 8, max = 72, message = "senha deve ter entre 8 e 72 caracteres")
        String senha) {
}
