package br.com.msav02.service;

/** Nomes SEM prefixo (o Spring adiciona "ROLE_" ao usar .roles()/hasRole()). */
public final class Roles {
    public static final String ADMIN = "ADMIN";
    public static final String MANUTENCAO = "MANUTENCAO";
    public static final String USER = "USER";

    private Roles() {
    }
}
