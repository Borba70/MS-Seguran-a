package br.com.msav02.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record LoginRequest(
        @Schema(example = "aluno") @NotBlank(message = "username é obrigatório") @Size(max = 100, message = "username deve ter no máximo 100 caracteres") String username,
        @Schema(example = "SenhaForte#123") @NotBlank(message = "senha é obrigatória") @Size(max = 128, message = "senha deve ter no máximo 128 caracteres") String senha) {
}
