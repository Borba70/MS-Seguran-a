package br.com.msav02.controller;

import br.com.msav02.dto.CadastroUsuarioRequest;
import br.com.msav02.dto.ErrorResponse;
import br.com.msav02.dto.UsuarioResponse;
import br.com.msav02.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Tag(name = "Usuários")
public class UsuarioController {

    private final UserService userService;

    public UsuarioController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Cadastra um novo usuário",
            description = "POST / — Requer ROLE_MANUTENCAO (HTTP Basic). A senha é gravada com BCrypt. "
                    + "O novo usuário recebe a role ROLE_USER.",
            security = @SecurityRequirement(name = "basicAuth"))
    @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(
            examples = @ExampleObject(name = "Exemplo", value = "{\"username\": \"novoUsuario\", \"senha\": \"senhaSegura#123\"}")))
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Usuário criado",
                    content = @Content(schema = @Schema(implementation = UsuarioResponse.class),
                            examples = @ExampleObject(value = "{\"username\": \"novoUsuario\", \"enabled\": true, \"locked\": false, \"roles\": [\"ROLE_USER\"]}"))),
            @ApiResponse(responseCode = "400", description = "Dados inválidos",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Não autenticado",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "403", description = "Sem ROLE_MANUTENCAO",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "409", description = "Username já existe",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                            examples = @ExampleObject(value = "{\"status\": 409, \"erro\": \"Conflict\", \"mensagem\": \"Já existe um usuário com esse username.\"}")))
    })
    public ResponseEntity<UsuarioResponse> cadastrar(@Valid @RequestBody CadastroUsuarioRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.cadastrar(request));
    }

    @GetMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Lista usuários",
            description = "GET / — Requer ROLE_MANUTENCAO (HTTP Basic). Retorna apenas username, estado da conta e roles; "
                    + "nunca senhas nem hashes.",
            security = @SecurityRequirement(name = "basicAuth"))
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista de usuários",
                    content = @Content(array = @ArraySchema(schema = @Schema(implementation = UsuarioResponse.class)),
                            examples = @ExampleObject(value = "[{\"username\": \"aluno\", \"enabled\": true, \"locked\": false, \"roles\": [\"ROLE_USER\"]}]"))),
            @ApiResponse(responseCode = "401", description = "Não autenticado",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "403", description = "Sem ROLE_MANUTENCAO",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    public List<UsuarioResponse> listar() {
        return userService.listar();
    }
}
