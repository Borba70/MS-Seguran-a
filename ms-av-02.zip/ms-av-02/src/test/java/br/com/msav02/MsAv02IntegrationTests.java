package br.com.msav02;

import br.com.msav02.service.Roles;
import br.com.msav02.service.UserService;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Testes de integracao: sobem o contexto Spring completo (com Spring Security real e H2 em memoria)
 * e exercitam os endpoints via MockMvc. Credenciais abaixo sao fictícias e existem so durante o teste.
 */
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureObservability // habilita o registry do Prometheus (desligado por padrao em @SpringBootTest)
class MsAv02IntegrationTests {

    private static final String ADMIN = "adm_teste";
    private static final String ADMIN_PASS = "Admin#12345";
    private static final String MANUT = "manut_teste";
    private static final String MANUT_PASS = "Manut#12345";
    private static final String ALUNO = "aluno";
    private static final String ALUNO_PASS = "Aluno#12345";

    @Autowired MockMvc mvc;
    @Autowired JdbcTemplate jdbc;
    @Autowired UserService userService;
    @Autowired MeterRegistry registry;

    @BeforeEach
    void prepararBanco() {
        jdbc.update("DELETE FROM authorities");
        jdbc.update("DELETE FROM login_attempts");
        jdbc.update("DELETE FROM usuarios");
        userService.criar(ADMIN, ADMIN_PASS, Roles.ADMIN);
        userService.criar(MANUT, MANUT_PASS, Roles.MANUTENCAO);
        userService.criar(ALUNO, ALUNO_PASS, Roles.USER);
    }

    // ---------- helpers ----------
    private ResultActions login(String user, String pass) throws Exception {
        return mvc.perform(post("/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"" + user + "\",\"senha\":\"" + pass + "\"}"));
    }

    private double counter(String name) {
        return registry.get(name).counter().count();
    }

    private void bloquearAluno() throws Exception {
        login(ALUNO, "errada1").andExpect(status().isUnauthorized());
        login(ALUNO, "errada2").andExpect(status().isUnauthorized());
    }

    private int falhas(String user) {
        return jdbc.queryForObject("SELECT failed_attempts FROM login_attempts WHERE username = ?", Integer.class, user);
    }

    private boolean locked(String user) {
        return jdbc.queryForObject("SELECT locked FROM login_attempts WHERE username = ?", Boolean.class, user);
    }

    private boolean enabled(String user) {
        return jdbc.queryForObject("SELECT enabled FROM usuarios WHERE username = ?", Boolean.class, user);
    }

    // ---------- login ----------
    @Test
    void loginValido_retorna200_eIncrementaContador() throws Exception {
        double antes = counter("login_validos");
        login(ALUNO, ALUNO_PASS).andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value(ALUNO));
        assertEquals(antes + 1, counter("login_validos"));
    }

    @Test
    void loginInvalido_retorna401_mensagemGenerica_eIncrementaContador() throws Exception {
        double antes = counter("login_invalidos");
        login(ALUNO, "senhaErrada").andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.mensagem").value("Usuário ou senha inválidos."));
        login("naoExiste", "qualquer").andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.mensagem").value("Usuário ou senha inválidos."));
        assertEquals(antes + 2, counter("login_invalidos"));
    }

    @Test
    void loginComCorpoInvalido_retorna400() throws Exception {
        mvc.perform(post("/login").contentType(MediaType.APPLICATION_JSON).content("{\"username\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void bloqueioAposDuasFalhasConsecutivas_eRecusaLoginDeUsuarioBloqueado() throws Exception {
        login(ALUNO, "errada1").andExpect(status().isUnauthorized());
        assertFalse(locked(ALUNO), "1 falha nao deve bloquear");
        login(ALUNO, "errada2").andExpect(status().isUnauthorized());
        assertTrue(locked(ALUNO), "2 falhas consecutivas devem bloquear");
        assertFalse(enabled(ALUNO));

        // Mesmo com a senha correta, usuario bloqueado nao entra.
        double validosAntes = counter("login_validos");
        login(ALUNO, ALUNO_PASS).andExpect(status().isUnauthorized());
        assertEquals(validosAntes, counter("login_validos"));
    }

    @Test
    void loginValidoZeraContadorDeFalhasConsecutivas() throws Exception {
        login(ALUNO, "errada1").andExpect(status().isUnauthorized());
        assertEquals(1, falhas(ALUNO));
        login(ALUNO, ALUNO_PASS).andExpect(status().isOk());
        assertEquals(0, falhas(ALUNO));
        login(ALUNO, "errada3").andExpect(status().isUnauthorized());
        assertFalse(locked(ALUNO), "falhas nao consecutivas nao devem bloquear");
    }

    // ---------- unlock ----------
    @Test
    void adminDesbloqueiaUsuario_eLoginVoltaAFuncionar() throws Exception {
        bloquearAluno();
        mvc.perform(put("/unlock/" + ALUNO).with(httpBasic(ADMIN, ADMIN_PASS)))
                .andExpect(status().isOk());
        assertFalse(locked(ALUNO));
        assertTrue(enabled(ALUNO));
        assertEquals(0, falhas(ALUNO));
        login(ALUNO, ALUNO_PASS).andExpect(status().isOk());
    }

    @Test
    void unlock_usuarioInexistente_retorna404() throws Exception {
        mvc.perform(put("/unlock/fantasma").with(httpBasic(ADMIN, ADMIN_PASS)))
                .andExpect(status().isNotFound());
    }

    @Test
    void unlock_semRoleAdmin_retorna403_eSemAutenticacao_retorna401() throws Exception {
        mvc.perform(put("/unlock/" + ALUNO).with(httpBasic(MANUT, MANUT_PASS))).andExpect(status().isForbidden());
        mvc.perform(put("/unlock/" + ALUNO)).andExpect(status().isUnauthorized());
    }

    // ---------- trocar senha ----------
    @Test
    void trocarSenha_comSenhaAtualCorreta_atualizaComBCrypt() throws Exception {
        mvc.perform(put("/trocarsenha/" + ALUNO).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"atual\":\"" + ALUNO_PASS + "\",\"nova\":\"NovaSenha#456\"}"))
                .andExpect(status().isOk());

        String hash = jdbc.queryForObject("SELECT senha FROM usuarios WHERE username = ?", String.class, ALUNO);
        assertTrue(hash.startsWith("$2"), "senha deve estar em BCrypt");
        assertFalse(hash.contains("NovaSenha#456"));
        login(ALUNO, "NovaSenha#456").andExpect(status().isOk());
        login(ALUNO, ALUNO_PASS).andExpect(status().isUnauthorized());
    }

    @Test
    void trocarSenha_comSenhaAtualIncorreta_retorna401_eNaoAltera() throws Exception {
        mvc.perform(put("/trocarsenha/" + ALUNO).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"atual\":\"errada\",\"nova\":\"NovaSenha#456\"}"))
                .andExpect(status().isUnauthorized());
        login(ALUNO, ALUNO_PASS).andExpect(status().isOk());
    }

    @Test
    void trocarSenha_usuarioInexistente_retorna404() throws Exception {
        mvc.perform(put("/trocarsenha/fantasma").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"atual\":\"x\",\"nova\":\"NovaSenha#456\"}"))
                .andExpect(status().isNotFound());
    }

    // ---------- cadastro ----------
    @Test
    void cadastro_comRoleManutencao_retorna201_senhaEmBCrypt_eBloqueiaDuplicado() throws Exception {
        String body = "{\"username\":\"novoUsuario\",\"senha\":\"senhaSegura#123\"}";
        mvc.perform(post("/").with(httpBasic(MANUT, MANUT_PASS)).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.username").value("novoUsuario"))
                .andExpect(content().string(not(containsString("senha"))));

        String hash = jdbc.queryForObject("SELECT senha FROM usuarios WHERE username = 'novoUsuario'", String.class);
        assertTrue(hash.startsWith("$2"));
        assertFalse(hash.contains("senhaSegura"));

        mvc.perform(post("/").with(httpBasic(MANUT, MANUT_PASS)).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isConflict());
        login("novoUsuario", "senhaSegura#123").andExpect(status().isOk());
    }

    @Test
    void cadastro_comDadosInvalidos_retorna400() throws Exception {
        mvc.perform(post("/").with(httpBasic(MANUT, MANUT_PASS)).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"a\",\"senha\":\"123\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cadastro_semRoleManutencao_retorna403_eAnonimo_retorna401() throws Exception {
        String body = "{\"username\":\"outro\",\"senha\":\"senhaSegura#123\"}";
        mvc.perform(post("/").with(httpBasic(ADMIN, ADMIN_PASS)).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isForbidden());
        mvc.perform(post("/").with(httpBasic(ALUNO, ALUNO_PASS)).contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isForbidden());
        mvc.perform(post("/").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isUnauthorized());
    }

    // ---------- listagem ----------
    @Test
    void listagem_comRoleManutencao_retorna200_semSenhaNemHash() throws Exception {
        mvc.perform(get("/").with(httpBasic(MANUT, MANUT_PASS)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.username=='" + ALUNO + "')]").exists())
                .andExpect(content().string(not(containsString("senha"))))
                .andExpect(content().string(not(containsString("$2a$"))))
                .andExpect(content().string(not(containsString("$2b$"))));
    }

    @Test
    void listagem_semPermissao_retorna403_eAnonimo_retorna401() throws Exception {
        mvc.perform(get("/").with(httpBasic(ALUNO, ALUNO_PASS))).andExpect(status().isForbidden());
        mvc.perform(get("/").with(httpBasic(ADMIN, ADMIN_PASS))).andExpect(status().isForbidden());
        mvc.perform(get("/")).andExpect(status().isUnauthorized());
    }

    @Test
    void credenciaisBasicInvalidas_retornam401() throws Exception {
        mvc.perform(get("/").with(httpBasic(MANUT, "senhaErrada"))).andExpect(status().isUnauthorized());
    }

    @Test
    void usuarioBloqueado_naoConsegueAutenticarEmRotaProtegida() throws Exception {
        // bloqueia o usuario de manutencao por 2 falhas e tenta usar a senha correta no Basic
        login(MANUT, "x1").andExpect(status().isUnauthorized());
        login(MANUT, "x2").andExpect(status().isUnauthorized());
        mvc.perform(get("/").with(httpBasic(MANUT, MANUT_PASS))).andExpect(status().isUnauthorized());
    }

    @Test
    void rotaNaoMapeada_eNegadaPorPadrao() throws Exception {
        mvc.perform(get("/qualquer-coisa")).andExpect(status().isUnauthorized());
        mvc.perform(get("/qualquer-coisa").with(httpBasic(ADMIN, ADMIN_PASS))).andExpect(status().isForbidden());
    }

    // ---------- metricas ----------
    @Test
    void metricas_expostasNoPrometheus_eGaugeRefleteBloqueados() throws Exception {
        mvc.perform(get("/actuator/prometheus"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("login_validos_total")))
                .andExpect(content().string(containsString("login_invalidos_total")))
                .andExpect(content().string(containsString("usuarios_bloqueados")));

        assertEquals(0.0, registry.get("usuarios_bloqueados_total").gauge().value());
        bloquearAluno();
        assertEquals(1.0, registry.get("usuarios_bloqueados_total").gauge().value());
        mvc.perform(put("/unlock/" + ALUNO).with(httpBasic(ADMIN, ADMIN_PASS))).andExpect(status().isOk());
        assertEquals(0.0, registry.get("usuarios_bloqueados_total").gauge().value());
    }

    // ---------- swagger ----------
    @Test
    void swagger_eOpenApi_estaoDisponiveis() throws Exception {
        mvc.perform(get("/v3/api-docs")).andExpect(status().isOk())
                .andExpect(content().string(containsString("/trocarsenha/{userid}")))
                .andExpect(content().string(containsString("/unlock/{userid}")));
        mvc.perform(get("/swagger-ui/index.html")).andExpect(status().isOk());
    }
}
