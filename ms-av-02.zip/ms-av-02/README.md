# MS-AV-02 — Segurança e Observabilidade

Projeto acadêmico em **Java 21 + Spring Boot 3.3**: autenticação com **Spring Security + JdbcUserDetailsManager (PostgreSQL)**, bloqueio de contas após falhas consecutivas, métricas com **Micrometer/Actuator → Prometheus → Grafana** e documentação com **Springdoc OpenAPI / Swagger UI**.
Funciona **sem Docker**, direto no Windows (VS Code + JDK + Maven + PostgreSQL).

> **Status de verificação (leia):** o código e os testes foram escritos, mas **não foram compilados nem executados** no ambiente em que este projeto foi gerado (sem Maven e sem acesso à internet). Rode `mvn clean test` na sua máquina e corrija o que eventualmente aparecer. Nenhum resultado de teste, métrica ou captura de tela foi inventado.

---

## 1. Objetivo
Implementar uma API REST com login, troca de senha, cadastro, listagem e desbloqueio de usuários, com autorização por roles, bloqueio automático após 2 falhas consecutivas e indicadores de observabilidade (logins válidos/inválidos e usuários bloqueados) visualizados no Grafana.

## 2. Tecnologias
Java 21 · Spring Boot 3.3.5 · Maven · Spring Security (`JdbcUserDetailsManager`, BCrypt) · PostgreSQL · Actuator + Micrometer (registry Prometheus) · Prometheus · Grafana · Springdoc OpenAPI 2.6 / Swagger UI · JUnit 5 + MockMvc (testes com H2 em memória) · Git/GitHub.

## 3. Estrutura
```
ms-av-02/
├── pom.xml
├── README.md
├── .gitignore
├── .env.example                      # modelo de configuração local (copie para .env)
├── database/
│   ├── 01_create_database.sql        # CREATE DATABASE msav02
│   ├── 02_schema.sql                 # tabelas (cópia de src/main/resources/schema.sql)
│   └── 03_reset_dev.sql              # apaga tabelas (só desenvolvimento)
├── prometheus/prometheus.yml
├── grafana/
│   ├── dashboard-ms-av-02.json       # dashboard exportável (3 painéis)
│   ├── datasource.yml                # provisionamento opcional
│   └── (dashboard.png)               # VOCÊ gera após executar (seção 12)
├── docs/roteiro-testes-manuais.md
└── src/
    ├── main/java/br/com/msav02/
    │   ├── MsAv02Application.java
    │   ├── config/        OpenApiConfig, BootstrapUsersRunner
    │   ├── controller/    LoginController, SenhaController, UsuarioController, AdminController
    │   ├── dto/           LoginRequest/Response, TrocaSenhaRequest, CadastroUsuarioRequest, UsuarioResponse, MensagemResponse, ErrorResponse
    │   ├── exception/     ApiException (+ subclasses), GlobalExceptionHandler
    │   ├── repository/    UserRepository, LoginAttemptRepository
    │   ├── security/      SecurityConfig, JsonAuthenticationEntryPoint, JsonAccessDeniedHandler, ErrorWriter
    │   └── service/       AuthService, UserService, LoginAttemptService, LoginMetrics, Roles
    ├── main/resources/    application.properties, schema.sql
    └── test/              MsAv02IntegrationTests + application.properties (H2)
```

## 4. Pré-requisitos (Windows, sem Docker)
| Item | Como obter |
|---|---|
| JDK 21 | `winget install EclipseAdoptium.Temurin.21.JDK` (ou https://adoptium.net) |
| Maven 3.9+ | `winget install Apache.Maven` (ou https://maven.apache.org/download.cgi) |
| PostgreSQL 15/16 | https://www.postgresql.org/download/windows/ (anote a senha do usuário `postgres`) |
| Git | `winget install Git.Git` |
| VS Code + "Extension Pack for Java" e "Spring Boot Extension Pack" | Marketplace do VS Code |
| Prometheus | zip para Windows em https://prometheus.io/download/ |
| Grafana OSS | instalador em https://grafana.com/grafana/download?platform=windows |

Verifique (feche e reabra o terminal após instalar): `java -version`, `mvn -v`, `psql --version`, `git --version`.
Se `psql` não for reconhecido, adicione `C:\Program Files\PostgreSQL\16\bin` ao PATH.

## 5. Banco de dados
```bat
psql -U postgres -f database\01_create_database.sql
```
(Se o banco já existir, ignore o erro.) As tabelas `usuarios`, `login_attempts` e `authorities` são criadas **automaticamente** na inicialização por `schema.sql` (idempotente). Para criar manualmente: `psql -U postgres -d msav02 -f database\02_schema.sql`.

Roles aceitas (restrição `CHECK`): `ROLE_ADMIN`, `ROLE_MANUTENCAO` e `ROLE_USER` (role padrão dos usuários cadastrados via `POST /`).

## 6. Configuração e credenciais de desenvolvimento
```bat
copy .env.example .env
notepad .env
```
Preencha `DB_PASSWORD` e as senhas `BOOTSTRAP_*` (mín. 8 caracteres). O `.env` é lido automaticamente (`spring.config.import=optional:file:.env[.properties]`) e **está no `.gitignore`**. Em vez do `.env` você pode usar variáveis de ambiente com os mesmos nomes (`setx DB_PASSWORD "..."`).

No primeiro start, se `BOOTSTRAP_ADMIN_*` e `BOOTSTRAP_MANUTENCAO_*` estiverem preenchidos e os usuários não existirem, eles são criados (admin → `ROLE_ADMIN`; manutenção → `ROLE_MANUTENCAO`) com senha em BCrypt. Nenhuma credencial existe no código-fonte.

## 7. Executar a aplicação
```bat
mvn clean package -DskipTests
mvn spring-boot:run
```
ou `java -jar target\ms-av-02-1.0.0.jar`.

| Serviço | URL |
|---|---|
| API | http://localhost:8080 |
| Swagger UI | http://localhost:8080/swagger-ui.html |
| OpenAPI JSON | http://localhost:8080/v3/api-docs |
| Métricas | http://localhost:8080/actuator/prometheus |
| Health | http://localhost:8080/actuator/health |
| Prometheus | http://localhost:9090 |
| Grafana | http://localhost:3000 |

## 8. Endpoints e autorização
| Método/Caminho | Acesso | Resposta |
|---|---|---|
| `POST /login` | público | 200 / 401 / 400 |
| `PUT /trocarsenha/{userid}` | público (exigência acadêmica) | 200 / 400 / 401 / 403 / 404 |
| `POST /` | `ROLE_MANUTENCAO` | 201 / 400 / 401 / 403 / 409 |
| `GET /` | `ROLE_MANUTENCAO` | 200 / 401 / 403 |
| `PUT /unlock/{userid}` | `ROLE_ADMIN` | 200 / 401 / 403 / 404 |
| Swagger, `/v3/api-docs`, `/actuator/health`, `/actuator/prometheus` | público | — |
| Qualquer outra rota | negada (`denyAll`) | 401/403 |

**Autenticação das rotas protegidas: HTTP Basic** (stateless, sem sessão). `POST /login` apenas valida credenciais e retorna 200/401 (não emite token, conforme o enunciado).

### Exemplos (cmd.exe — substitua pelos valores do seu `.env`)
```bat
:: Login
curl -i -X POST http://localhost:8080/login -H "Content-Type: application/json" -d "{\"username\":\"aluno\",\"senha\":\"SenhaForte#123\"}"

:: Cadastro (manutenção)
curl -i -u manutencao:SUA_SENHA -X POST http://localhost:8080/ -H "Content-Type: application/json" -d "{\"username\":\"aluno\",\"senha\":\"SenhaForte#123\"}"

:: Listar (manutenção)
curl -i -u manutencao:SUA_SENHA http://localhost:8080/

:: Trocar senha (público)
curl -i -X PUT http://localhost:8080/trocarsenha/aluno -H "Content-Type: application/json" -d "{\"atual\":\"SenhaForte#123\",\"nova\":\"OutraSenha#456\"}"

:: Desbloquear (admin)
curl -i -u admin:SUA_SENHA -X PUT http://localhost:8080/unlock/aluno
```
PowerShell: use `curl.exe` (não o alias `curl`) e coloque o JSON em arquivo: `curl.exe -X POST http://localhost:8080/login -H "Content-Type: application/json" -d "@login.json"`.

**Postman:** aba *Authorization* → Type **Basic Auth** → informe usuário/senha; em *Body* escolha **raw → JSON**.
**Swagger UI:** botão **Authorize** → informe usuário/senha (Basic) → *Try it out*.

## 9. Testes automatizados
Os testes de integração sobem o contexto completo (Spring Security real, `JdbcUserDetailsManager`, Actuator/Prometheus, Springdoc) usando **H2 em memória** (`src/test/resources/application.properties`) — **não precisam de PostgreSQL** nem de `.env`.
```bat
mvn clean test
```
Cobertura: login válido/inválido; bloqueio após 2 falhas; recusa de login bloqueado; zerar falhas após sucesso; desbloqueio por admin (200/404/403/401); troca de senha (correta, incorreta, inexistente, hash BCrypt); cadastro (201, 409, 400, 403, 401); listagem sem senha/hash; rota não mapeada negada; métricas (counters e gauge); Swagger/OpenAPI.
Para validar contra o **PostgreSQL real**, siga o [roteiro manual](docs/roteiro-testes-manuais.md).

## 10. Métricas
| Métrica | Tipo | Significado |
|---|---|---|
| `login_validos_total` | Counter | logins válidos acumulados |
| `login_invalidos_total` | Counter | logins inválidos acumulados (inclui tentativa em conta bloqueada e usuário inexistente) |
| `usuarios_bloqueados_total` | Gauge | quantidade **atual** de usuários bloqueados (consulta `login_attempts.locked = true` a cada coleta) |

**Counter × Gauge:** *Counter* só aumenta (zera apenas quando a aplicação reinicia) e responde "quantos eventos já ocorreram"; usa-se `rate()`/`increase()` para variação. *Gauge* é um valor instantâneo que sobe e desce — é o certo para "quantos bloqueados agora", pois o desbloqueio reduz o valor.

Nenhuma métrica tem labels (sem username, sem dado pessoal).

> **Atenção ao nome do gauge:** o gauge é registrado no Micrometer como `usuarios_bloqueados_total`, mas versões recentes do cliente Prometheus podem **remover o sufixo `_total` de métricas que não são Counter** na exposição. Confira com `curl http://localhost:8080/actuator/prometheus | findstr bloqueados`. O dashboard usa `usuarios_bloqueados_total or usuarios_bloqueados`, então funciona nos dois casos. Os counters aparecem com `_total`.
> Os contadores ficam em memória: reiniciam em zero quando a aplicação reinicia (comportamento normal do Counter; o Prometheus lida com isso em `rate()`/`increase()`).

## 11. Prometheus e Grafana (sem Docker)
**Prometheus**
1. Baixe o zip *windows-amd64* e extraia (ex.: `C:\prometheus`).
2. Execute (ajuste o caminho do projeto):
```bat
cd C:\prometheus
prometheus.exe --config.file=C:\caminho\ms-av-02\prometheus\prometheus.yml
```
3. Abra http://localhost:9090/targets — o job `ms-av-02` deve estar **UP** (a aplicação precisa estar rodando).

**Grafana**
1. Instale o MSI (roda como serviço) e acesse http://localhost:3000. O login inicial padrão do Grafana é `admin`/`admin`; ele pedirá a troca da senha.
2. **Fonte de dados:** *Connections → Data sources → Add data source → Prometheus* → URL `http://localhost:9090` → **Save & test**. (Alternativa: `grafana/datasource.yml` em `conf\provisioning\datasources\`.)
3. **Importar dashboard:** *Dashboards → New → Import → Upload JSON file* → `grafana/dashboard-ms-av-02.json` → selecione a fonte Prometheus → **Import**.

**Consultas PromQL dos 3 painéis**
```
sum(login_validos_total)
sum(login_invalidos_total)
max(usuarios_bloqueados_total or usuarios_bloqueados)
```

**Exportar o dashboard após alterações:** abra o dashboard → **Export → Export as JSON** → marque *Export for sharing externally* → salve sobre `grafana/dashboard-ms-av-02.json`.

## 12. Captura de tela real (`grafana/dashboard.png`)
A captura **não foi gerada** — ela precisa vir da sua execução real:
1. Suba PostgreSQL, aplicação, Prometheus e Grafana.
2. Gere dados: alguns logins válidos, alguns inválidos e bloqueie um usuário (2 falhas seguidas) para o painel de bloqueados mostrar 1.
3. Abra o dashboard (intervalo *Last 15 minutes*), pressione **Win + Shift + S**, selecione a área do dashboard.
4. Cole no Paint → *Salvar como PNG* em `grafana\dashboard.png` dentro do projeto.
5. `git add grafana/dashboard.png`.

## 13. Conflitos entre segurança e enunciado (riscos e alternativas)
| Decisão do enunciado | Risco | Mitigação aplicada | Alternativa mais segura |
|---|---|---|---|
| `PUT /trocarsenha/{userid}` **público** | Qualquer pessoa pode tentar adivinhar a senha atual de qualquer usuário (força bruta) e descobrir quais usernames existem (404 × 401) | Exige a senha atual; senha atual errada **conta como falha** e leva ao bloqueio (mesmo limite do login); BCrypt; nova ≠ atual | Exigir autenticação (o próprio usuário) ou token de redefinição enviado por e-mail |
| Bloqueio por falhas em endpoint público | **Negação de serviço dirigida**: um atacante pode bloquear contas alheias errando a senha de propósito | Desbloqueio apenas por admin | Bloqueio temporário com expiração, limite por IP (rate limiting), CAPTCHA |
| `POST /login` sem token | O login só "valida"; não há sessão/token. As rotas protegidas usam Basic | Basic stateless | JWT/sessão após login |
| HTTP Basic | Credenciais em cada requisição; em HTTP puro trafegam sem criptografia (Base64 não é proteção) | Aceitável em `localhost` acadêmico | Usar **HTTPS/TLS** em qualquer ambiente real |
| `/actuator/prometheus` público | Expõe métricas operacionais a qualquer cliente | Sem labels/dados pessoais; só `health` e `prometheus` expostos | Proteger com Basic + `basic_auth` no `prometheus.yml`, ou restringir por rede/porta de gerenciamento |
| Mensagem de conta bloqueada | Revelaria que a conta existe | Só é dita a quem acertou a senha; demais veem mensagem genérica (também há hash fictício para equalizar o tempo) | — |
| CSRF desabilitado | Seria risco com cookies de sessão | API stateless sem cookies | Reativar se migrar para sessão |
| Senhas BCrypt | BCrypt considera só os primeiros 72 bytes | Limite de 72 caracteres na validação | Argon2/pepper, se exigido |

Também: o administrador **não** tem `ROLE_MANUTENCAO` (e vice-versa), conforme as regras do enunciado; o usuário de manutenção cria usuários só com `ROLE_USER` (não pode se autopromover).

## 14. Publicar no GitHub
```bat
cd C:\caminho\ms-av-02
git init
git add .
git status
git commit -m "feat: MS-AV-02 seguranca e observabilidade"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/ms-av-02.git
git push -u origin main
```
Crie antes o repositório **público** vazio em https://github.com/new (sem README/.gitignore). Com GitHub CLI: `gh repo create ms-av-02 --public --source=. --remote=origin --push`.
**Antes do commit**, confirme com `git status` que `.env` **não** aparece na lista (ele está no `.gitignore`). Se uma senha vazou para um commit, troque-a — apagar o commit não basta.

## 15. Checklist final
- [ ] Java 21, Spring Boot 3.x, Maven
- [ ] Spring Security + `JdbcUserDetailsManager` configurado com tabelas/colunas do projeto (`SecurityConfig`)
- [ ] PostgreSQL; tabelas `usuarios`, `login_attempts`, `authorities` (`schema.sql`)
- [ ] `POST /login` 200/401, contagem válidos/inválidos, bloqueio após 2 falhas, zera após sucesso, bloqueado não entra
- [ ] `PUT /trocarsenha/{userid}` público, valida atual, BCrypt, 200/401/404, riscos documentados (seção 13)
- [ ] `POST /` somente `ROLE_MANUTENCAO`, BCrypt, validação, duplicado 409, retorna 201
- [ ] `PUT /unlock/{userid}` somente `ROLE_ADMIN`, zera contador, 404 se inexistente
- [ ] `GET /` somente `ROLE_MANUTENCAO`, sem senha/hash
- [ ] Demais rotas negadas; 401/403 em JSON; Swagger/OpenAPI acessíveis
- [ ] Admin e manutenção iniciais via `.env`/variáveis, sem credenciais no código
- [ ] Métricas `login_validos_total`, `login_invalidos_total`, `usuarios_bloqueados_total`; `/actuator/prometheus`; sem labels pessoais
- [ ] `prometheus.yml`, dashboard JSON com 3 painéis, PromQL, datasource, instruções de importação
- [ ] **(você)** `mvn clean test` verde na sua máquina
- [ ] **(você)** verificar o nome real do gauge em `/actuator/prometheus`
- [ ] **(você)** gerar `grafana/dashboard.png` real
- [ ] **(você)** conferir que `.env` não está versionado e publicar no GitHub
