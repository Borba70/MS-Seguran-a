# Grafana

- `dashboard-ms-av-02.json` — dashboard exportável (3 painéis). Importe em *Dashboards → New → Import*.
- `datasource.yml` — provisionamento opcional da fonte Prometheus.
- `dashboard.png` — **não incluída**: gere a captura real conforme a seção 12 do README principal.
